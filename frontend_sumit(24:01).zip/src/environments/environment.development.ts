export const environment = {
    production: false,
    apiURL: 'https://www.distributelive.com/'
    // apiURL: 'http://localhost:8000/'
};