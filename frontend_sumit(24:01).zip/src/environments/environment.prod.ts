export const environment = {
    production: true,
    apiURL: 'https://www.distributelive.com/',
    // apiURL: 'http://localhost:8000/'
};