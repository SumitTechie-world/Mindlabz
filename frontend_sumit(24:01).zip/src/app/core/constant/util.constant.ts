export const localStorageConstant =  {
    hotelDetails:'hotel_details',
    servicesObject: 'service_details',
}