export const authAPI = {
    login: 'login'
}