export const logsAPI = {
    getAllLogs: 'getQueryLogs',
    getCustomLogs: 'get24onlinelogs',
    getNotifications:'getNotification?hotelId=:hotelId',
    createNotifications: 'createNotification',
    regenerateLog: 'real-time/repush?bookingId='
}