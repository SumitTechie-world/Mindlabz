export const hotelAPI = {
    getAllsubscriptions: 'getAllsubscriptions',
    deactivateHotel: 'deactivateHotel',
    createService: 'subscribe',
    createServiceCauseTwo: 'token',
    getServices: 'getInterface',
    getAllHotels: 'getSystemUsers',
    createHotel: 'craeteSystemUser',
    updateHotelStaus: 'updateSystemUser',
    getVendors: 'getInterfacelist',
    uploadRoomJson: 'importRooms',
    uploadGuestJson: 'importGuest'
}