export const commonConstant = {
    admin_role: 'admin',
    hotel_role: 'hotel'
}