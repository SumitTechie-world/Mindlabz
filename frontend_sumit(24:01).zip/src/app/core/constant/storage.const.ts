export const storageConstant = {
    access_token: 'access_token',
    role: 'role',
    login_object:'login_object',
}