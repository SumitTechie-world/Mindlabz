export const urlRoutes = {
    forgot_password: 'forgot-password',
    admin: 'admin',
    hotel: 'hotel',
    hotel_hotel_services: 'hotel-services',
    admin_hotels: 'hotels',
    admin_hotel_services: 'hotel-services',
    services_console: 'services-console',
    dashboard: 'dashboard',
    gupshup: 'gupshup',
    gupshup_dashbord: 'gupshup-dashboard',
    usage: 'usage'
}