import { Component } from '@angular/core';

@Component({
  selector: 'app-add-templates',
  templateUrl: './add-templates.component.html',
  styleUrl: './add-templates.component.scss'
})
export class AddTemplatesComponent {

}
