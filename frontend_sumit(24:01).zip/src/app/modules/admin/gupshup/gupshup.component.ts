import { Component } from '@angular/core';

@Component({
  selector: 'app-gupshup',
  templateUrl: './gupshup.component.html',
  styleUrl: './gupshup.component.scss'
})
export class GupshupComponent {

}
