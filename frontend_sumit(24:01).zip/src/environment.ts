export const environment = {
    url:"http://localhost:8000",
    // url:"https://www.distributelive.com",
    gupshup:"https://api.gupshup.io/sm/api/",
    gupshupApikey:"kuvch0plf6qldmzczbthjrtkfjwqowmp"
}
